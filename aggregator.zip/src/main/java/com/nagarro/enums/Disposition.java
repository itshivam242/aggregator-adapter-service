package com.nagarro.enums;

public enum Disposition {
    DeliveryByChannel
}